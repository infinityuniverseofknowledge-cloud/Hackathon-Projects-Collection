import { defineConfig } from 'vitest/config';
import path from 'path';
export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    coverage: { provider: 'v8', reporter: ['text', 'html'], include: ['lib/**/*.ts'] },
  },
  resolve: { alias: { '@': path.resolve(__dirname, './') } },
});
