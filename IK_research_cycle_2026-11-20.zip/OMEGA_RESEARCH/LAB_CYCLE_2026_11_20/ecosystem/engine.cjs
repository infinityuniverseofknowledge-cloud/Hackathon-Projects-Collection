'use strict';
// Load the exact engine embedded in the offline HTML; no duplicated model code.
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'ecosystem.html'),'utf8');
const match=html.match(/<script id="engine">([\s\S]*?)<\/script>/);
if(!match) throw Error('Embedded engine not found');
const context={};vm.createContext(context);vm.runInContext(match[1],context,{timeout:1000});
if(!context.PatchPulse) throw Error('Engine did not export');
module.exports=context.PatchPulse;
