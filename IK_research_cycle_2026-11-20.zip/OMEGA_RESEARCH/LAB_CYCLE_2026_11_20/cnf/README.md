# Quantified CNF projection: a finite computational audit

Prepared for Miqueias B Werlich / Infinity Knowledge. Working research note, 20 November 2026.

## Objective and scope
Check, by two implementations, a standard elimination identity for formulas of the form `exists X forall Y: F(X,Y)` where F is CNF. This is not the founder's Polynomial Certificate Hierarchies framework: its primary documents were unavailable. Neither novelty nor a complexity-class separation is claimed.

## Method
For each clause delete it if it contains both polarities of a universal variable; otherwise erase its universal literals. Evaluate the resulting CNF on X and compare with direct evaluation of all Y assignments. Enumerate every distinct set of 0, 1 or 2 clauses from 256 syntactic clauses over four variables (each variable absent, positive, negative or both). Direct and projected paths use the same truth evaluator, so this is not fully independent verification. Empty clauses and tautologies are included. Distinct syntactic formulas need not be semantically distinct.

## Executed result
On 32,897 formulas, 0 projection mismatches and 0 violations of `exists X forall Y F => forall Y exists X F`; 64 cases show the converse fails. Counts and one example are in `results.json`. These finite results are not a universal proof or evidence of an efficient solution to general SAT.

## Why the identity works
For a fixed X assignment, universal quantification distributes over the finite conjunction of clauses. If X makes a clause true it remains true. If not, the remaining disjunction of Y literals is true for every Y assignment exactly when it contains a variable in both polarities. Removing the Y-tautological clauses and the Y-literals from other clauses therefore preserves satisfaction for each X assignment. This elementary argument is independent of the empirical enumeration but has not undergone expert peer review; it is not asserted to be original. The resulting CNF may remain NP-hard to satisfy; the experiment does not implement a polynomial certificate hierarchy.

## Run and tests
Python standard library: `python3 -m unittest -v test_cnf_lab`; `python3 cnf_lab.py`. The second command writes results.json in this directory. Eleven unit tests passed on Python 3.14.4 on 20 November 2026.

## References
- J. Nordström, *A (Biased) Proof Complexity Survey for SAT Practitioners*, 2014: https://jakobnordstrom.se/docs/publications/SAT2014InvitedTalkExtendedAbstract.pdf
- T. Pitassi and I. Tzameret, *Algebraic Proof Complexity: Progress, Frontiers and Challenges*, 2016: https://arxiv.org/abs/1607.00443

## Limitations and next checks
No archived ASOG definitions were available. Search more broadly for previous quantified-CNF elimination results before claiming any novelty. Cross-check independently against a QBF solver and vary clause sizes, variable partitions and encodings; review the argument formally. No external publication or license assignment has been made.
