import unittest
import cnf_lab as lab


class ProjectionTests(unittest.TestCase):
    def test_empty_formula_is_true(self):
        self.assertTrue(lab.exists_forall(()))
        self.assertEqual(lab.project((), {3, 4}), ())

    def test_empty_clause_is_false(self):
        self.assertFalse(lab.exists_forall(((),)))
        self.assertEqual(lab.project(((),), {3, 4}), ((),))

    def test_universal_tautology_is_removed(self):
        self.assertEqual(lab.project(((1, 3, -3),), {3, 4}), ())
        self.assertTrue(lab.exists_forall(((1, 3, -3),)))

    def test_universal_only_clause_becomes_empty(self):
        self.assertEqual(lab.project(((3, -4),), {3, 4}), ((),))
        self.assertFalse(lab.exists_forall(((3, -4),)))

    def test_existential_tautology_remains_true(self):
        self.assertTrue(lab.projected_exists(((1, -1, 3),)))

    def test_conflicting_existential_units(self):
        self.assertFalse(lab.projected_exists(((1,), (-1,))))

    def test_order_matters(self):
        # x iff y: each x has a matching y, but no x works for all y.
        f = ((-1, 3), (1, -3))
        self.assertFalse(lab.exists_forall(f))
        self.assertTrue(lab.forall_exists(f))

    def test_fixed_x_assignment_equivalence_for_all_single_clauses(self):
        for clause in lab.clause_universe():
            f = (clause,)
            p = lab.project(f, set(lab.Y))
            for a in lab.assignments(lab.X):
                self.assertEqual(lab.eval_cnf(p, a),
                                 all(lab.eval_cnf(f, a | b) for b in lab.assignments(lab.Y)),
                                 (clause, a))

    def test_clause_universe_unique_and_includes_extremes(self):
        cs = lab.clause_universe()
        self.assertEqual(len(set(cs)), 256)
        self.assertIn((), cs)
        self.assertIn((1, -1, 2, -2, 3, -3, 4, -4), cs)

    def test_empty_universal_set_is_identity(self):
        f = ((1, -2), (), (2, -2))
        self.assertEqual(lab.project(f, set()), f)

    def test_only_universal_variables(self):
        p = lab.project(((3, -3), (4,)), {3, 4})
        self.assertEqual(p, ((),))
        self.assertFalse(lab.eval_cnf(p, {}))


if __name__ == '__main__':
    unittest.main()
