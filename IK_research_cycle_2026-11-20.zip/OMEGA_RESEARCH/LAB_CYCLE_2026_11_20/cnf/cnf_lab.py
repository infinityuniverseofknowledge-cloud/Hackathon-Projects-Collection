#!/usr/bin/env python3
"""Exhaustively check a quantified-CNF projection on a fixed finite corpus.
Literals are signed nonzero integers; CNFs are tuples of clauses.
"""
from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path

X = (1, 2)
Y = (3, 4)
V = X + Y


def assignments(variables):
    for values in product((False, True), repeat=len(variables)):
        yield dict(zip(variables, values))


def eval_cnf(formula, values):
    return all(any(values[abs(lit)] == (lit > 0) for lit in clause)
               for clause in formula)


def exists_forall(formula):
    return any(all(eval_cnf(formula, a | b) for b in assignments(Y))
               for a in assignments(X))


def forall_exists(formula):
    # Quantifier swap preserves the roles of X and Y: forall Y, exists X.
    return all(any(eval_cnf(formula, a | b) for a in assignments(X))
               for b in assignments(Y))


def project(formula, universal):
    """Delete Y-tautological clauses and erase other Y-literals."""
    projected = []
    for clause in formula:
        s = set(clause)
        if any(v in s and -v in s for v in universal):
            continue
        projected.append(tuple(lit for lit in clause if abs(lit) not in universal))
    return tuple(projected)


def projected_exists(formula):
    projection = project(formula, set(Y))
    return any(eval_cnf(projection, a) for a in assignments(X))


def clause_universe():
    # State per variable: absent, positive, negative, both. Empty allowed.
    choices = [(), (1,), (-1,), (1, -1)]
    return tuple(tuple(sign * v for v, states in zip(V, shape) for sign in states)
                 for shape in product(choices, repeat=len(V)))


def experiment():
    clauses = clause_universe()
    assert len(clauses) == len(set(clauses)) == 256
    counts = Counter()
    examples = {}
    for size in range(3):
        for formula in combinations(clauses, size):
            ef = exists_forall(formula)
            fe = forall_exists(formula)
            compiled = projected_exists(formula)
            counts['formula_count'] += 1
            counts[f'clauses_{size}'] += 1
            counts['exists_forall_true'] += ef
            counts['forall_exists_true'] += fe
            counts['projection_mismatches'] += ef != compiled
            counts['implication_violations'] += ef and not fe
            counts[f'EF_{int(ef)}_FE_{int(fe)}'] += 1
            if fe and not ef and 'strict_order_example' not in examples:
                examples['strict_order_example'] = [list(c) for c in formula]
    required = ['formula_count', 'clauses_0', 'clauses_1', 'clauses_2',
                'exists_forall_true', 'forall_exists_true', 'projection_mismatches',
                'implication_violations', 'EF_0_FE_0', 'EF_0_FE_1',
                'EF_1_FE_0', 'EF_1_FE_1']
    result = {'description': 'All distinct-clause CNFs of size 0, 1, or 2 over 4 variables',
              'X_existential_first': list(X), 'Y_universal_second': list(Y),
              'clause_universe_count': len(clauses),
              'counts': {key: counts[key] for key in required}, 'examples': examples}
    assert counts['formula_count'] == 32897
    assert not counts['projection_mismatches'] and not counts['implication_violations']
    return result


if __name__ == '__main__':
    result = experiment()
    text = json.dumps(result, indent=2, sort_keys=True) + '\n'
    Path(__file__).with_name('results.json').write_text(text, encoding='utf-8')
    print(text, end='')
