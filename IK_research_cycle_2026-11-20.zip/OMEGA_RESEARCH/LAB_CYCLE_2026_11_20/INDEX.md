# Infinity Knowledge: independent research cycle, 2026-11-20

Prepared for Miqueias B Werlich. This index is a local cycle index, **not** the inaccessible authoritative research master log. UUID-like local identifiers below do not claim continuity with P-series numbering. Existing founder frameworks and claims are not reconstructed from their names. Human scientific review and rights review remain outstanding.

| Local identifier | Study | Status | Files |
|---|---|---|---|
| LAB-20261120-CNF-f9d71b2e | Quantified CNF projection finite audit | 32,897 formulas enumerated, 11 tests passed; note awaiting review | [Research note](cnf/README.md), [code](cnf/cnf_lab.py), [results](cnf/results.json) |
| LAB-20261120-ECO-7c3ad46b | Toy ring metapopulation shock comparison | 100 paired simulations, 14 unit tests and desktop headless browser smoke test passed; Android untested | [Research note](ecosystem/README.md), [simulator](ecosystem/ecosystem.html), [results](ecosystem/experiment_summary.json), [data](ecosystem/experiment_results.csv) |

[Ten opportunities](opportunities/OPPORTUNITIES.md) are proposals, not validated discoveries. A reproducible proof-complexity connection to the founder's Polynomial Certificate Hierarchies, and the definitions of ASOG, SVCA and related frameworks, remain unverified pending source recovery.

## Reproduction
CNF: from `cnf/`, run `python3 -m unittest -v test_cnf_lab` and `python3 cnf_lab.py`. The second overwrites the generated `results.json`. Ecology: from `ecosystem/`, run `node test.cjs` and `node experiment.cjs`; the latter overwrites its synthetic CSV and summary. Preserve originals before rerunning if audit timestamps are needed. The simulator is a self-contained HTML file.

## Repository and provenance
GitHub public repository https://github.com/infinityuniverseofknowledge-cloud/Hackathon-Projects-Collection, main inspected at 62facd2eb0ff05c315dcc4262c63b49e0f1b1367. Existing content preserved. Local Git author is automation, not a claim that the founder personally wrote the files. Nothing in this cycle is peer reviewed; no novelty, licensing readiness, real-world ecological prediction, or universal complexity result is established.
