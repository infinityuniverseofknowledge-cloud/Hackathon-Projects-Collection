"""Regenerate three pre-specified replicates per cell and compare saved pair fields and trajectories."""
import csv
from pathlib import Path
from experiment import simulate
P=Path(__file__).resolve().parent
with (P/'pairs.csv').open(newline='') as f: pairs=[r for r in csv.DictReader(f) if int(r['rep']) in (1,40,80)]
keys={(x['generator'],x['c'],x['e'],x['rep']) for x in pairs}; raw={key:[] for key in keys}
with (P/'trajectories.csv').open(newline='') as f:
 for r in csv.DictReader(f):
  k=(r['generator'],r['c'],r['e'],r['rep'])
  if k in raw:raw[k].append(tuple(int(r[x]) for x in ('t','control_count','cluster_count','dispersed_count')))
for p in pairs:
 key=(p['generator'],p['c'],p['e'],p['rep']);fresh,traj=simulate(key[0],float(key[1]),float(key[2]),int(key[3]))
 for field,value in fresh.items(): assert p[field]==str(value), (key,field,p[field],value)
 assert traj==raw[key],key
print('PASS: exact saved-pair fields and every count replayed for 54 attempted runs (three per cell)')
