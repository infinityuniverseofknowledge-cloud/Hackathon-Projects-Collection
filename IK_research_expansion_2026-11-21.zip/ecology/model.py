"""Independent Python implementation. All draws in step() are supplied by caller."""
import hashlib, random
MASK=(1<<64)-1
class SplitMix64:
    def __init__(self, seed): self.state=seed & MASK
    def random(self):
        self.state=(self.state+0x9e3779b97f4a7c15)&MASK
        z=self.state; z=((z^(z>>30))*0xbf58476d1ce4e5b9)&MASK
        z=((z^(z>>27))*0x94d049bb133111eb)&MASK
        z=z^(z>>31)
        return (z>>11)/2**53

def seed_for(rep, stream):
    return int.from_bytes(hashlib.sha256(f'patch-pulse-v2:{rep}:{stream}'.encode()).digest()[:8], 'big')

def rng(kind, seed):
    if kind=='mt19937': return random.Random(seed)
    if kind=='splitmix64': return SplitMix64(seed)
    raise ValueError('unknown generator')

def step(state, c, e, draws):
    n=len(state)
    if n<3 or len(draws)!=n or not 0<=c<=1 or not 0<=e<=1: raise ValueError('invalid inputs')
    if any(x not in (0,1) for x in state) or any(not 0<=u<1 for u in draws): raise ValueError('invalid values')
    return [int(draws[i] >= e) if state[i] else int(draws[i] < 1-(1-c)**(state[(i-1)%n]+state[(i+1)%n])) for i in range(n)]

def shock_sets(state, k, offset):
    """Consecutive occupied sites in ring order vs greedy farthest point spread.
    Offset breaks ties deterministically. Both remove k actually occupied sites.
    This is not the unique way to define clustered/dispersed.
    """
    n=len(state); occupied=[(offset+i)%n for i in range(n) if state[(offset+i)%n]]
    if k<0 or k>len(occupied): raise ValueError('infeasible removal')
    cluster=occupied[:k]
    if not k: return cluster,[]
    dispersed=[occupied[0]]; candidates=occupied[1:]
    while len(dispersed)<k:
        def distance(i): return min(min((i-j)%n,(j-i)%n) for j in dispersed)
        best=max(candidates,key=distance); dispersed.append(best); candidates.remove(best)
    return cluster, dispersed

def remove(state, indices):
    s=state.copy()
    if len(indices)!=len(set(indices)) or any(i<0 or i>=len(s) or s[i]!=1 for i in indices): raise ValueError('must remove distinct occupied sites')
    for i in indices: s[i]=0
    return s

def edges(indices,n):
    s=set(indices); return sum(i in s and (i+1)%n in s for i in range(n))

def adjacent_gaps(indices,n):
    if not indices: return 0
    q=sorted(indices); return max((q[(i+1)%len(q)]-q[i])%n for i in range(len(q)))
