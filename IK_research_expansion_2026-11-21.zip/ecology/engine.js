'use strict';
// Independent JavaScript implementation of the supplied-uniform transition.
(function(root){
  function step(s,c,e,u){
    const n=s.length;if(n<3||u.length!==n||!(c>=0&&c<=1&&e>=0&&e<=1)||s.some(x=>x!==0&&x!==1)||u.some(x=>!(x>=0&&x<1)))throw Error('invalid model inputs');
    return s.map((x,i)=>x?Number(u[i]>=e):Number(u[i]<1-Math.pow(1-c,s[(i+n-1)%n]+s[(i+1)%n])));
  }
  function shocks(s,k,offset){
    const n=s.length, occ=[]; for(let i=0;i<n;i++){const p=(offset+i)%n;if(s[p])occ.push(p)}
    if(!Number.isInteger(k)||k<0||k>occ.length)throw Error('infeasible shock');
    let cluster=occ.slice(0,k);if(!k)return [cluster,[]];
    let dispersed=[occ[0]],cand=occ.slice(1);
    while(dispersed.length<k){let best=0,bestD=-1;for(let j=0;j<cand.length;j++){let d=Math.min(...dispersed.map(x=>Math.min((cand[j]-x+n)%n,(x-cand[j]+n)%n)));if(d>bestD){bestD=d;best=j}}dispersed.push(cand.splice(best,1)[0])}
    return [cluster,dispersed];
  }
  function remove(s,inds){let a=s.slice(),seen=new Set();for(const i of inds){if(!Number.isInteger(i)||i<0||i>=a.length||seen.has(i)||!a[i])throw Error('invalid removal');seen.add(i);a[i]=0}return a}
  function generator(seed){let x=seed>>>0;if(!x)x=0x6d2b79f5;return function(){x^=x<<13;x^=x>>>17;x^=x<<5;x>>>=0;return x/4294967296}}
  const api={step,shocks,remove,generator};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PatchLab=api;
})(typeof globalThis!=='undefined'?globalThis:this);
