import unittest, random, json, subprocess, sys, csv
from pathlib import Path
from model import step, shock_sets, remove, edges, SplitMix64, seed_for
from experiment import simulate, K, HORIZON
P=Path(__file__).resolve().parent
class ModelTests(unittest.TestCase):
 def test_rng_reference_vector(self):
  r=SplitMix64(0)
  self.assertEqual([int(r.random()*2**53) for _ in range(3)],[0xe220a8397b1dcdaf>>11,0x6e789e6aa1b965f4>>11,0x06c45d188009454f>>11])
 def test_all_occupied_no_extinction(self):self.assertEqual(step([1]*8,1,0,[0]*8),[1]*8)
 def test_all_occupied_extinction_one(self):self.assertEqual(step([1]*8,1,1,[0]*8),[0]*8)
 def test_extinction_absorbing(self):self.assertEqual(step([0]*8,1,0,[0]*8),[0]*8)
 def test_ring_wrap(self):self.assertEqual(step([1,0,0,0],1,0,[0]*4),[1,1,0,1])
 def test_synchronous(self):self.assertEqual(step([1,0,0,0,0],1,1,[0]*5),[0,1,0,0,1])
 def test_probability_boundary(self):self.assertEqual(step([1,0,0,0],0.5,0.5,[.5,.5,0,.499]),[1,0,0,1])
 def test_invalid_inputs(self):
  for s,c,e,u in [([0,1],.2,.1,[0,0]),([0,1,2],.2,.1,[0,0,0]),([0,1,0],1.1,.1,[0,0,0]),([0,1,0],.1,.1,[0,1,0])]:
   with self.assertRaises(ValueError):step(s,c,e,u)
 def test_shocks_equal_and_occupied_many_states(self):
  r=random.Random(43)
  for _ in range(100):
   s=[int(r.random()<.7) for i in range(64)];a,b=shock_sets(s,12,r.randrange(64))
   self.assertEqual(len(set(a)),12);self.assertEqual(len(set(b)),12)
   self.assertEqual(sum(s)-sum(remove(s,a)),12);self.assertEqual(sum(s)-sum(remove(s,b)),12)
 def test_shock_impossible(self):
  with self.assertRaises(ValueError):shock_sets([0]*64,12,0)
 def test_duplicate_invalid(self):
  with self.assertRaises(ValueError):remove([1,1,1],[1,1])
 def test_ring_rotation(self):
  s=[1,0,1,0,0,1];u=[.1,.8,.5,.3,.9,.2];r=2
  self.assertEqual(step(s[r:]+s[:r],.2,.4,u[r:]+u[:r]),step(s,.2,.4,u)[r:]+step(s,.2,.4,u)[:r])
 def test_repeatable(self):self.assertEqual(simulate('splitmix64',.22,.08,3),simulate('splitmix64',.22,.08,3))
 def test_pair_immediate_equal(self):
  r,t=simulate('mt19937',.22,.08,7);self.assertEqual(t[0][1]-t[0][2],K);self.assertEqual(t[0][1]-t[0][3],K);self.assertEqual(len(t),HORIZON+1)
 def test_seeds_stream_separated(self):self.assertNotEqual(seed_for(1,'dynamics'),seed_for(1,'shock-offset'))
 def test_python_js_parity_many_transitions_and_shocks(self):
  r=random.Random(991);cases=[]
  for _ in range(400):
   n=r.randrange(3,80);s=[r.randrange(2) for _ in range(n)];u=[r.random() for _ in range(n)];c=r.random();e=r.random();k=r.randrange(sum(s)+1);offset=r.randrange(n)
   cases.append(dict(s=s,u=u,c=c,e=e,k=k,offset=offset,expected=step(s,c,e,u),shocks=shock_sets(s,k,offset)))
  proc=subprocess.run(['node',str(P/'parity.cjs')],input=json.dumps(cases),text=True,capture_output=True,check=True)
  self.assertEqual(proc.stdout.strip(),'400 transition and shock parity cases passed')
if __name__=='__main__':unittest.main(verbosity=2)
