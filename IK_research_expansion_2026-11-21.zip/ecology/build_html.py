from pathlib import Path
p=Path(__file__).resolve().parent
template=(p/'template.html').read_text();engine=(p/'engine.js').read_text()
assert template.count('/*ENGINE*/')==1
(p/'patch_lab.html').write_text(template.replace('/*ENGINE*/',engine))
print('Built patch_lab.html; standalone, no network dependencies')
