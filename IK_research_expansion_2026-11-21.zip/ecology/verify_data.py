"""Audit raw trajectories against per-pair records without the simulator."""
import csv, itertools, json, math
from pathlib import Path
from statistics import mean
P=Path(__file__).resolve().parent
with (P/'pairs.csv').open(newline='') as f: pairs=list(csv.DictReader(f))
bykey={(r['generator'],r['c'],r['e'],r['rep']):r for r in pairs}; seen=set(); records=0
with (P/'trajectories.csv').open(newline='') as f:
 for key,group in itertools.groupby(csv.DictReader(f),lambda r:(r['generator'],r['c'],r['e'],r['rep'])):
  assert key in bykey and key not in seen;seen.add(key);p=bykey[key];a=list(group);records+=len(a)
  assert p['eligible']=='1' and len(a)==101 and [int(x['t']) for x in a]==list(range(101))
  assert int(a[0]['control_count'])==int(p['pre'])
  for name in ('cluster','dispersed'):
   vals=[int(x[name+'_count']) for x in a];ctrl=[int(x['control_count']) for x in a]
   assert vals[0]==ctrl[0]-12 and len(set(map(int,p[name+'_indices'].split(';'))))==12
   assert all(0<=x<=64 for x in vals)
   assert abs(mean(vals[1:])/64-float(p[name+'_mean']))<1e-12
   streak=0;event=None
   for t in range(1,101):
    streak=streak+1 if ctrl[t]>0 and vals[t]>=.9*ctrl[t] else 0
    if streak>=5 and event is None:event=t
   assert int(p[name+'_event'])==int(event is not None)
   assert p[name+'_event_time']==(str(event) if event is not None else '')
   assert int(p[name+'_rmst_observed'])==(event or 100)
   assert int(p[name+'_final'])==vals[-1]
  assert abs(float(p['dispersed_mean'])-float(p['cluster_mean'])-float(p['delta_mean']))<1e-12
eligible=[p for p in pairs if p['eligible']=='1'];assert len(seen)==len(eligible)
with (P/'summary.json').open() as f:summary=json.load(f)
for cell in summary['cells']:
 p=[x for x in eligible if x['generator']==cell['generator'] and float(x['c'])==cell['c'] and float(x['e'])==cell['e']]
 assert len(p)==cell['eligible']
 if p:
  assert abs(mean(float(x['delta_mean']) for x in p)-cell['paired_difference'])<1e-12
  assert sum(int(x['cluster_event']) for x in p)==cell['cluster_recovered']
  assert sum(int(x['dispersed_event']) for x in p)==cell['dispersed_recovered']
print(f'PASS: {len(pairs)} attempted pairs, {len(eligible)} eligible pairs, {records} trajectory rows; means, recovery, censoring and summary agree')
