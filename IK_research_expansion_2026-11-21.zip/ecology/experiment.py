#!/usr/bin/env python3
"""Recreate paired model experiments and all summaries using stdlib only."""
import csv, json, math, platform, sys
from pathlib import Path
from statistics import mean, stdev
from model import rng, seed_for, step, shock_sets, remove, edges
HERE=Path(__file__).resolve().parent
N=64; BURN=40; HORIZON=100; K=12; REPS=80
PARAMS=[(c,e) for c in (0.12,0.22,0.35) for e in (0.04,0.08,0.16)]
FIELDS=['generator','c','e','rep','seed','eligible','pre','removed','cluster_edges','dispersed_edges','cluster_indices','dispersed_indices','cluster_mean','dispersed_mean','delta_mean','cluster_event_time','dispersed_event_time','cluster_event','dispersed_event','cluster_rmst_observed','dispersed_rmst_observed','cluster_final','dispersed_final']
def ci(xs):
    if len(xs)<2:return [None,None]
    m=mean(xs); h=1.96*stdev(xs)/math.sqrt(len(xs));return [m-h,m+h]
def simulate(kind,c,e,rep):
    seed=seed_for(rep,'dynamics'); r=rng(kind,seed); off=seed_for(rep,'shock-offset')%N
    state=[1]*N
    for _ in range(BURN): state=step(state,c,e,[r.random() for _ in range(N)])
    pre=sum(state); base={'generator':kind,'c':c,'e':e,'rep':rep,'seed':seed,'eligible':int(pre>=K),'pre':pre}
    if pre<K: return base,[]
    a,b=shock_sets(state,K,off)
    branches=[state,remove(state,a),remove(state,b)]
    traj=[(0,*map(sum,branches))]; streak=[0,0]; event=[None,None]; sums=[0,0]
    for t in range(1,HORIZON+1):
        draws=[r.random() for _ in range(N)]
        branches=[step(x,c,e,draws) for x in branches]
        control,cluster,dispersed=map(sum,branches); traj.append((t,control,cluster,dispersed))
        for j,count in enumerate((cluster,dispersed)):
            sums[j]+=count/N
            # If control is extinct, ratio is undefined: reset streak, no event.
            streak[j]=streak[j]+1 if control>0 and count>=0.9*control else 0
            if streak[j]>=5 and event[j] is None: event[j]=t
    base.update({'removed':K,'cluster_edges':edges(a,N),'dispersed_edges':edges(b,N),'cluster_indices':';'.join(map(str,a)),'dispersed_indices':';'.join(map(str,b)),'cluster_mean':sums[0]/HORIZON,'dispersed_mean':sums[1]/HORIZON,'delta_mean':(sums[1]-sums[0])/HORIZON,'cluster_event_time':event[0] or '', 'dispersed_event_time':event[1] or '', 'cluster_event':int(event[0] is not None),'dispersed_event':int(event[1] is not None),'cluster_rmst_observed':event[0] or HORIZON,'dispersed_rmst_observed':event[1] or HORIZON,'cluster_final':traj[-1][2],'dispersed_final':traj[-1][3]})
    return base,traj

def run():
    rows=[]
    with (HERE/'trajectories.csv').open('w',newline='') as tf:
        tw=csv.writer(tf);tw.writerow(['generator','c','e','rep','t','control_count','cluster_count','dispersed_count'])
        for kind in ('mt19937','splitmix64'):
            for c,e in PARAMS:
                for rep in range(1,REPS+1):
                    row,traj=simulate(kind,c,e,rep);rows.append(row)
                    for t,ctrl,a,b in traj:tw.writerow([kind,c,e,rep,t,ctrl,a,b])
    with (HERE/'pairs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    summaries=[]
    for kind in ('mt19937','splitmix64'):
        for c,e in PARAMS:
            allr=[x for x in rows if x['generator']==kind and x['c']==c and x['e']==e]; eligible=[x for x in allr if x['eligible']]
            if not eligible: summaries.append({'generator':kind,'c':c,'e':e,'eligible':0,'excluded':len(allr)});continue
            diff=[x['delta_mean'] for x in eligible]; rt=[x['dispersed_rmst_observed']-x['cluster_rmst_observed'] for x in eligible]
            summaries.append({'generator':kind,'c':c,'e':e,'eligible':len(eligible),'excluded':len(allr)-len(eligible),'mean_pre':mean(x['pre'] for x in eligible),'mean_edges_cluster':mean(x['cluster_edges'] for x in eligible),'mean_edges_dispersed':mean(x['dispersed_edges'] for x in eligible),'mean_occupancy_cluster':mean(x['cluster_mean'] for x in eligible),'mean_occupancy_dispersed':mean(x['dispersed_mean'] for x in eligible),'paired_difference':mean(diff),'paired_difference_normal_95_ci':ci(diff),'positive_pairs':sum(x>0 for x in diff),'negative_pairs':sum(x<0 for x in diff),'ties':sum(x==0 for x in diff),'cluster_recovered':sum(x['cluster_event'] for x in eligible),'dispersed_recovered':sum(x['dispersed_event'] for x in eligible),'cluster_restricted_mean_time':mean(x['cluster_rmst_observed'] for x in eligible),'dispersed_restricted_mean_time':mean(x['dispersed_rmst_observed'] for x in eligible),'paired_restricted_time_difference':mean(rt),'paired_restricted_time_difference_normal_95_ci':ci(rt),'cluster_final_extinctions':sum(x['cluster_final']==0 for x in eligible),'dispersed_final_extinctions':sum(x['dispersed_final']==0 for x in eligible)})
    result={'design':{'nodes':N,'burn':BURN,'followup':HORIZON,'removal_count':K,'replicates_attempted_per_cell':REPS,'parameters':PARAMS,'generators':['mt19937','splitmix64'],'seed':'first 64 bits SHA-256 patch-pulse-v2:<rep>:dynamics; offset uses distinct label','common_random_numbers':'one supplied uniform per site per time, shared control and both branches','recovery':'first completion of five consecutive steps occupancy >= 90% of concurrent unshocked control, control > 0; horizon-censored at 100','intervals':'paired normal approximation 1.96 standard errors, exploratory, no multiplicity correction','python':sys.version,'platform':platform.platform()},'cells':summaries}
    (HERE/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print('wrote',len(rows),'pairs;',sum(x['eligible'] for x in rows),'eligible')
if __name__=='__main__':run()
