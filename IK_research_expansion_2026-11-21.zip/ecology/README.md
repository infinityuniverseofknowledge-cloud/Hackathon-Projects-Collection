# Patch Lab — research extension

Working, exploratory, synthetic simulation. Prepared for Miqueias B Werlich / Infinity Knowledge. Not peer reviewed, ecological validation, a new theorem, or management advice. Original baseline was preserved at `/home/daytona/workspace/output/lab_cycle_2026_11_20/ecosystem/`.

## Files
- `MANUSCRIPT.md`: English research note, complete methods, cell-by-cell results, references and explicit limitations.
- `model.py`, `experiment.py`: executable Python reference model, protocol and analysis; standard library only.
- `pairs.csv`: every one of 1,440 attempted pairs, exclusions, IDs/seeds, removed site indices, geometry, outcomes and censoring.
- `trajectories.csv`: 131,805 rows, control and both treatments at shock time 0 and steps 1–100, for 1,305 eligible pairs.
- `summary.json`: protocol, platform and all 18 condition summaries, effects, approximate intervals and recovery statistics.
- `test_model.py`, `parity.cjs`, `verify_data.py`, `test_results.txt`: unit/property, JS/Python supplied-draw parity, and raw output audit.
- `patch_lab.html`: standalone offline interactive viewer, not a re-run of the Python results. Controls, equal-removal intervention, paired trajectories and CSV export; uses xorshift32 rather than either research generator. `engine.js`, `template.html`, and `build_html.py` reproduce it.
- `browser_test_dom.html`, `browser_test_stderr.log`: desktop Chromium self-test artifacts; stderr may include harmless environment warnings.

## Reproduce
In this directory (Python 3.14.4, Node v20.19.2 and Chromium 148 used here):

```
python experiment.py       # replaces pairs.csv, trajectories.csv, summary.json
python test_model.py       # 16 tests, including 400 Python/JS parity cases
python verify_data.py      # audits raw records and summaries
python build_html.py       # embeds engine.js into patch_lab.html
chromium --headless --no-sandbox --disable-gpu --disable-dev-shm-usage --dump-dom 'file://'"$PWD"'/patch_lab.html?selftest=1' > browser_test_dom.html 2> browser_test_stderr.log
```

The final HTML body should contain `data-selftest="PASS"`. To use the simulator, open the local standalone HTML; set parameters and Reset, step to a chosen burn-in, apply paired shock, then advance. Exported CSV records time, event and counts; the shock is a separate row at the same time as the preceding pre-shock row. The line graph plots row order (including the extra shock row), not exact elapsed-time spacing at that discontinuity. Parameters take effect only on Reset. No browser network calls or remote assets are required. Android, assistive technology, accessibility compliance, downloads and long-duration mobile performance remain unverified.

## Critical interpretation
Exactly 12 occupied sites are removed from each branch, but selected site identities differ, so the intervention contrasts two selection algorithms rather than isolating a pure spatial effect. Excluded low-occupancy runs are not randomized away, making the analysis conditional on eligibility. Recovery is completion of a five-step period at 90% of the concurrently unshocked control, conditional on a positive reference; it does not prove lasting recovery. Intervals are unadjusted normal approximations for paired model runs. Neither source literature nor cross-code consistency validates the model as ecology. Full caveats and data documentation are in the manuscript.
