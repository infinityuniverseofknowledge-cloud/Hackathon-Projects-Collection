"""Two-block CNF projection and an independent recursive SAT decision procedure.
Python >=3.8, standard library only. Literals are nonzero signed integers.
"""


def validate(cnf, xs, ys):
    xs, ys = tuple(xs), tuple(ys)
    if any(type(v) is not int or v <= 0 for v in xs + ys):
        raise ValueError('variables must be positive integers')
    if len(set(xs + ys)) != len(xs + ys):
        raise ValueError('variables must be unique and partitions disjoint')
    variables = set(xs + ys)
    for clause in cnf:
        for lit in clause:
            if type(lit) is not int or lit == 0 or abs(lit) not in variables:
                raise ValueError('invalid or undeclared literal: %r' % (lit,))


def project(cnf, xs, ys):
    """Return CNF representing forall ys: cnf for each assignment to xs."""
    validate(cnf, xs, ys)
    universals = set(ys)
    out = []
    for clause in cnf:
        seen = set(clause)
        if any(v in seen and -v in seen for v in universals):
            continue
        out.append(tuple(lit for lit in clause if abs(lit) not in universals))
    return tuple(out)


def sat(cnf):
    """Simple DPLL with unit propagation; returns (satisfiable, node count).

    No preprocessing claim is made. Tautologies and duplicate literals are
    normalized internally; this is not a competitive SAT solver.
    """
    clauses = []
    for clause in cnf:
        s = frozenset(clause)
        if any(-lit in s for lit in s):
            continue
        clauses.append(s)
    nodes = [0]

    def solve(cs):
        nodes[0] += 1
        while True:
            if not cs:
                return True
            if any(not c for c in cs):
                return False
            unit = next((next(iter(c)) for c in cs if len(c) == 1), None)
            if unit is None:
                break
            cs = [c - {-unit} for c in cs if unit not in c]
        # Sort gives reproducible decisions independent of hash iteration order.
        lit = min(min(cs, key=lambda c: (len(c), tuple(sorted(c)))),
                  key=lambda x: (abs(x), x))
        return (solve([c - {-lit} for c in cs if lit not in c]) or
                solve([c - {lit} for c in cs if -lit not in c]))

    answer = solve(clauses)
    return answer, nodes[0]


def exists_forall(cnf, xs, ys):
    return sat(project(cnf, xs, ys))
