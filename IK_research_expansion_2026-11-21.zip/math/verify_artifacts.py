#!/usr/bin/env python3
"""Verify stored randomized inputs, results, checksums, and summaries."""
import collections
import hashlib
import json
from pathlib import Path
import qbf_projection as p
import truth_oracle as o

root = Path(__file__).resolve().parent
r = json.loads((root / 'results.json').read_text(encoding='utf-8'))
raw = (root / 'random_cases.jsonl').read_bytes()
assert hashlib.sha256(raw).hexdigest() == r['random_cases_sha256']
rows = [json.loads(line) for line in raw.splitlines()]
assert len(rows) == r['random_case_count']
summaries = collections.defaultdict(collections.Counter)
for row in rows:
    group = row['group']
    x, y, w, m = (int(s[1:]) for s in group.split('_'))
    xs = tuple(range(1, x + 1))
    ys = tuple(range(x + 1, x + y + 1))
    f = tuple(tuple(c) for c in row['formula'])
    assert len(f) == m and all(len(c) == w and len({abs(z) for z in c}) == w for c in f)
    ef = o.decide(f, [('E', v) for v in xs] + [('A', v) for v in ys])
    fe = o.decide(f, [('A', v) for v in ys] + [('E', v) for v in xs])
    projected = p.project(f, xs, ys)
    sat, nodes = p.sat(projected)
    assert (ef, fe, nodes) == (row['ef'], row['fe'], row['dpll_nodes'])
    assert sat == ef and not (ef and not fe)
    assert o.truth_vector(projected, xs) == o.universal_residual(f, xs, ys)
    c = summaries[group]
    c['samples'] += 1
    c['ef_true'] += ef
    c['fe_true'] += fe
    c['strict_order_gap'] += fe and not ef
    c['projection_mismatch'] += 0
    c['implication_violations'] += 0
    c['oracle_total_ns'] += row['truth_table_ef_ns']
    c['projection_sat_total_ns'] += row['project_sat_ns']
    c['dpll_nodes_total'] += nodes
assert set(summaries) == set(r['random_groups'])
for group, counts in summaries.items():
    assert dict(counts) == r['random_groups'][group], group
print('PASS: %d stored random cases, %d groups, checksum, recorded decisions, and residuals' % (len(rows), len(summaries)))
