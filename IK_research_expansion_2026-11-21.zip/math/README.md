# Quantified-CNF research expansion

Working research deliverable prepared for Miqueias B Werlich / Infinity Knowledge. English scientific note; no novelty, original-framework equivalence, external publication, or peer-review claim. Previous cycle code was read but not imported or modified.

## Contents

- `MANUSCRIPT.md` — definitions, self-contained proof, relation to existing universal reduction, experimental protocol/results, real references, limitations and next steps.
- `qbf_projection.py` — restricted trailing-universal CNF projection and elementary DPLL SAT solver.
- `truth_oracle.py` — independently implemented full truth-table oracle for arbitrary quantifier prefixes, plus residuals.
- `test_qbf.py` — 11 unit test methods, including 500 seeded generalized random cases and edge cases.
- `experiments.py` — reproduces five exhaustive corpora, seeded random parameter sweep and structured equality family.
- `results.json` — complete recorded aggregate results, system metadata, and hashes.
- `random_cases.jsonl` — all 1,800 random matrices and their results and measured timings.
- `verify_artifacts.py` — verifies the raw-file SHA-256, each random decision and residual, and every random group aggregate.

## Recorded outcomes

- Five exhaustive corpus/partition combinations: 207,877 cases and 787,763 fixed-X comparisons, zero projection or solver decision mismatches, zero implication violations. Counts include the same 3-variable formulas under different partitions.
- Independent replication of previous n=4 corpus: 32,897 cases, 64 strict order gaps.
- 1,800 seeded random cases across 36 groups: 523 EF true, 653 FE true, 130 strict gaps; zero discrepancies.
- Structured equality family k=1…7 and all 11 test methods passed; the retained random data verification passed for all 1,800 cases.
- Python 3.14.4 on the sandbox; standard library only. Python 3.8+ intended but not separately tested. Android/Termux not tested. No external solver or certificate used.

## Commands

From this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_qbf
PYTHONDONTWRITEBYTECODE=1 python3 verify_artifacts.py
PYTHONDONTWRITEBYTECODE=1 python3 experiments.py
```

The last command overwrites the two recorded data files in this directory with a new run. Timings are exploratory and vary. The SHA-256 of the JSONL is also run-dependent because timings are included. Keep a copy of the recorded data before re-running if the exact original observations matter. Do not use Python's `-O` option, which disables the assertions in the audit scripts. The truth-table oracle requires exponential memory and is intended for small inputs only.
