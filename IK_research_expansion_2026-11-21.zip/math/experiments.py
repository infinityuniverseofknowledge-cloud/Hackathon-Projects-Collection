#!/usr/bin/env python3
"""Run deterministic exhaustive audits and seeded random/structured studies.
Writes only inside this directory. Times are descriptive, not portable.
"""
import hashlib
import itertools
import json
import platform
import random
import sys
import time
from collections import Counter
from pathlib import Path

import qbf_projection as p
import truth_oracle as o

ROOT = Path(__file__).resolve().parent
SEED = 20261121


def universe(n):
    return [tuple(lit for v, state in zip(range(1, n + 1), shape)
                  for lit in ((), (v,), (-v,), (v, -v))[state])
            for shape in itertools.product(range(4), repeat=n)]


def prefixes(xs, ys):
    return ([('E', x) for x in xs] + [('A', y) for y in ys],
            [('A', y) for y in ys] + [('E', x) for x in xs])


def audit(n, k, max_clauses):
    variables = tuple(range(1, n + 1))
    xs, ys = variables[:k], variables[k:]
    clauses = universe(n)
    counts = Counter()
    example = None
    digest = hashlib.sha256()
    ef_prefix, fe_prefix = prefixes(xs, ys)
    started = time.perf_counter()
    for m in range(max_clauses + 1):
        for f in itertools.combinations(clauses, m):
            residual = o.universal_residual(f, xs, ys)
            projected = p.project(f, xs, ys)
            proj_rows = o.truth_vector(projected, xs)
            ef, fe = o.decide(f, ef_prefix), o.decide(f, fe_prefix)
            sat, _ = p.sat(projected)
            counts['formulas'] += 1
            counts['fixed_x_rows_checked'] += len(residual)
            counts['residual_mismatch_formulas'] += residual != proj_rows
            counts['sat_oracle_mismatch'] += sat != ef
            counts['ef_true'] += ef
            counts['fe_true'] += fe
            counts['implication_violations'] += ef and not fe
            counts['strict_order_gap'] += fe and not ef
            digest.update((json.dumps(f, separators=(',', ':')) + '\n').encode())
            if fe and not ef and example is None:
                example = f
    if counts['residual_mismatch_formulas'] or counts['sat_oracle_mismatch'] or counts['implication_violations']:
        raise AssertionError('Exhaustive audit failed: %s' % dict(counts))
    return {'n': n, 'x': list(xs), 'y': list(ys), 'max_clauses': max_clauses,
            'clause_universe_size': len(clauses), 'counts': dict(counts),
            'first_order_gap_example': example, 'corpus_sha256_jsonl': digest.hexdigest(),
            'elapsed_seconds': round(time.perf_counter() - started, 6)}


def random_study():
    rng = random.Random(SEED)
    rows = []
    groups = {}
    for nx, ny in ((1, 1), (2, 2), (3, 3), (4, 2), (2, 4)):
        n = nx + ny
        xs, ys = tuple(range(1, nx + 1)), tuple(range(nx + 1, n + 1))
        ef_prefix, fe_prefix = prefixes(xs, ys)
        for requested_width in (2, 3):
            if requested_width > n:
                continue
            for m in (2, 4, 8, 12):
                key = 'x%d_y%d_w%d_m%d' % (nx, ny, requested_width, m)
                counts = Counter()
                for sample in range(50):
                    f = tuple(tuple(v * rng.choice((-1, 1)) for v in
                                    sorted(rng.sample(range(1, n + 1), requested_width)))
                              for _ in range(m))
                    t = time.perf_counter_ns()
                    ef = o.decide(f, ef_prefix)
                    oracle_ns = time.perf_counter_ns() - t
                    fe = o.decide(f, fe_prefix)
                    t = time.perf_counter_ns()
                    projected = p.project(f, xs, ys)
                    sat, nodes = p.sat(projected)
                    projected_ns = time.perf_counter_ns() - t
                    residual = o.universal_residual(f, xs, ys)
                    mismatch = residual != o.truth_vector(projected, xs)
                    if mismatch or sat != ef or (ef and not fe):
                        raise AssertionError('random audit failed in %s sample %s' % (key, sample))
                    counts['samples'] += 1
                    counts['ef_true'] += ef
                    counts['fe_true'] += fe
                    counts['strict_order_gap'] += fe and not ef
                    counts['projection_mismatch'] += mismatch
                    counts['implication_violations'] += ef and not fe
                    counts['oracle_total_ns'] += oracle_ns
                    counts['projection_sat_total_ns'] += projected_ns
                    counts['dpll_nodes_total'] += nodes
                    rows.append({'group': key, 'sample': sample, 'formula': f,
                                 'ef': ef, 'fe': fe, 'dpll_nodes': nodes,
                                 'truth_table_ef_ns': oracle_ns, 'project_sat_ns': projected_ns})
                groups[key] = dict(counts)
    return rows, groups


def equality_study():
    rows = []
    for k in range(1, 8):
        xs = tuple(range(1, k + 1))
        ys = tuple(range(k + 1, 2 * k + 1))
        f = tuple(c for x, y in zip(xs, ys) for c in ((-x, y), (x, -y)))
        ef_prefix, fe_prefix = prefixes(xs, ys)
        ef, fe = o.decide(f, ef_prefix), o.decide(f, fe_prefix)
        projected = p.project(f, xs, ys)
        sat, nodes = p.sat(projected)
        assert not ef and fe and not sat
        rows.append({'k': k, 'formula': f, 'ef': ef, 'fe': fe,
                     'projected_formula': projected, 'dpll_nodes': nodes,
                     'oracle_rows_per_decision': 2 ** (2 * k)})
    return rows


def main():
    all_audits = [audit(3, k, 3) for k in range(4)]
    all_audits.append(audit(4, 2, 2))
    raw, groups = random_study()
    structured = equality_study()
    raw_text = ''.join(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n' for row in raw)
    (ROOT / 'random_cases.jsonl').write_text(raw_text, encoding='utf-8')
    result = {'seed': SEED, 'python': sys.version, 'platform': platform.platform(),
              'notes': 'Elapsed timings are environment-specific and include Python overhead.',
              'exhaustive': all_audits, 'random_case_count': len(raw),
              'random_cases_sha256': hashlib.sha256(raw_text.encode()).hexdigest(),
              'random_groups': groups, 'equality_family': structured}
    (ROOT / 'results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'exhaustive': all_audits, 'random_cases': len(raw),
                      'random_groups': len(groups), 'equality_cases': len(structured)}, indent=2))


if __name__ == '__main__':
    main()
