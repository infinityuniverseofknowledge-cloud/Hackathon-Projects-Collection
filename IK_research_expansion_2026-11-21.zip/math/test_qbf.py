import itertools
import random
import unittest

import qbf_projection as p
import truth_oracle as o


class BasicTests(unittest.TestCase):
    def test_constants(self):
        self.assertTrue(o.decide((), ()))
        self.assertFalse(o.decide(((),), ()))
        self.assertEqual(p.sat(()), (True, 1))
        self.assertEqual(p.sat(((),)), (False, 1))

    def test_operators_and_fold_order(self):
        f = ((-1, 2), (1, -2))
        self.assertFalse(o.decide(f, (('E', 1), ('A', 2))))
        self.assertTrue(o.decide(f, (('A', 2), ('E', 1))))
        self.assertTrue(o.decide(f, (('E', 1), ('E', 2))))
        self.assertFalse(o.decide(f, (('A', 1), ('A', 2))))
        # Three alternations, not merely the two-block special case.
        self.assertTrue(o.decide(((1, -2, 3), (-1, 2, -3)),
                                 (('A', 1), ('E', 2), ('A', 3))))

    def test_tautology_and_duplicates(self):
        f = ((1, -1, 2), (2, 2), (1, 1, -2), (1, 1, -2))
        self.assertEqual(p.project(f, (1,), (2,)), ((1, -1), (), (1, 1), (1, 1)))
        self.assertFalse(p.exists_forall(f, (1,), (2,))[0])
        self.assertEqual(o.universal_residual(f, (1,), (2,)), [False, False])

    def test_empty_partitions(self):
        self.assertTrue(p.exists_forall((), (), ())[0])
        self.assertFalse(p.exists_forall(((1,),), (), (1,))[0])
        self.assertTrue(p.exists_forall(((1,),), (1,), ())[0])
        self.assertEqual(o.universal_residual(((1, -1),), (), (1,)), [True])

    def test_existential_tautology(self):
        f = ((1, -1, 2),)
        self.assertEqual(p.project(f, (1,), (2,)), ((1, -1),))
        self.assertTrue(p.exists_forall(f, (1,), (2,))[0])

    def test_validation(self):
        for f, xs, ys in [(((0,),), (1,), ()), (((2,),), (1,), ()),
                          (((True,),), (1,), ()), ((), (1,), (1,)),
                          ((), (0,), ()), ((), (True,), ())]:
            with self.assertRaises(ValueError):
                p.project(f, xs, ys)
        with self.assertRaises(ValueError):
            o.decide(((1,),), (('Z', 1),))
        with self.assertRaises(ValueError):
            o.truth_vector(((1,),), (1, 1))
        with self.assertRaises(ValueError):
            o.truth_vector(((0,),), (1,))

    def test_dpll_nontrivial(self):
        unsat = ((1, 2), (1, -2), (-1, 2), (-1, -2))
        self.assertFalse(p.sat(unsat)[0])
        self.assertTrue(p.sat(unsat[:-1])[0])

    def test_bad_rule_is_detected(self):
        # Incorrectly erasing a universal tautology creates an empty clause.
        f = ((2, -2),)
        self.assertEqual(o.universal_residual(f, (1,), (2,)), [True, True])
        self.assertEqual(o.truth_vector(((),), (1,)), [False, False])

    def test_exhaustive_single_clauses_four_variables(self):
        variables = (1, 2, 3, 4)
        for shape in itertools.product(range(4), repeat=4):
            clause = tuple(lit for v, state in zip(variables, shape)
                           for lit in ((), (v,), (-v,), (v, -v))[state])
            for k in range(5):
                xs, ys = variables[:k], variables[k:]
                f = (clause,)
                self.assertEqual(o.truth_vector(p.project(f, xs, ys), xs),
                                 o.universal_residual(f, xs, ys))

    def test_seeded_generalized_properties(self):
        rng = random.Random(20261121)
        for _ in range(500):
            n = rng.randint(0, 7)
            variables = list(range(1, n + 1))
            rng.shuffle(variables)
            k = rng.randrange(n + 1)
            xs, ys = variables[:k], variables[k:]
            clauses = []
            for _ in range(rng.randrange(8)):
                clauses.append(tuple(rng.choice((-1, 1)) * rng.choice(variables)
                                     for _ in range(rng.randrange(6))) if variables else ())
            f = tuple(clauses)
            residual = o.universal_residual(f, xs, ys)
            projected = p.project(f, xs, ys)
            self.assertEqual(o.truth_vector(projected, xs), residual)
            ef = o.decide(f, [('E', x) for x in xs] + [('A', y) for y in ys])
            fe = o.decide(f, [('A', y) for y in ys] + [('E', x) for x in xs])
            self.assertEqual(p.sat(projected)[0], ef)
            self.assertFalse(ef and not fe)
            self.assertEqual(p.sat(projected)[0], p.sat(tuple(reversed(projected)))[0])

    def test_equality_family(self):
        for n in range(1, 6):
            xs = tuple(range(1, n + 1))
            ys = tuple(range(n + 1, 2 * n + 1))
            f = tuple(c for x, y in zip(xs, ys) for c in ((-x, y), (x, -y)))
            self.assertFalse(o.decide(f, [('E', x) for x in xs] + [('A', y) for y in ys]))
            self.assertTrue(o.decide(f, [('A', y) for y in ys] + [('E', x) for x in xs]))
            self.assertFalse(p.exists_forall(f, xs, ys)[0])


if __name__ == '__main__':
    unittest.main()
