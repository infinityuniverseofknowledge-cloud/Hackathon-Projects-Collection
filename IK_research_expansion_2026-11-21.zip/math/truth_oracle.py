"""Independent truth-table QBF oracle (no imports from projection module).

Rows are ordered lexicographically with the rightmost variable changing
fastest. The solver computes the entire truth vector, then folds pairs from
right to left according to quantifier prefix. Exponential memory and time.
"""
from itertools import product


def truth_vector(cnf, variables):
    variables = tuple(variables)
    if any(type(v) is not int or v <= 0 for v in variables) or len(set(variables)) != len(variables):
        raise ValueError('invalid variable order')
    positions = {v: i for i, v in enumerate(variables)}
    # Convert literals to index/polarity independently of projection logic.
    matrix = []
    for clause in cnf:
        row = []
        for lit in clause:
            if type(lit) is not int or lit == 0 or abs(lit) not in positions:
                raise ValueError('invalid or undeclared literal')
            row.append((positions[abs(lit)], lit > 0))
        matrix.append(row)
    result = []
    for values in product((False, True), repeat=len(variables)):
        value = True
        for clause in matrix:
            clause_value = False
            for pos, polarity in clause:
                if values[pos] == polarity:
                    clause_value = True
                    break
            if not clause_value:
                value = False
                break
        result.append(value)
    return result


def decide(cnf, prefix):
    """prefix is iterable of ('E'|'A', variable), outermost first."""
    prefix = tuple(prefix)
    if any(q not in ('E', 'A') for q, _ in prefix):
        raise ValueError('quantifier must be E or A')
    values = truth_vector(cnf, [v for _, v in prefix])
    for q, _ in reversed(prefix):
        if q == 'E':
            values = [values[i] or values[i + 1] for i in range(0, len(values), 2)]
        else:
            values = [values[i] and values[i + 1] for i in range(0, len(values), 2)]
    return values[0]


def universal_residual(cnf, xs, ys):
    """For each ordered X assignment, aggregate rows universally over Y."""
    xs, ys = tuple(xs), tuple(ys)
    values = truth_vector(cnf, xs + ys)
    width = 1 << len(ys)
    return [all(values[i:i + width]) for i in range(0, len(values), width)]
