# A Reproducible Audit of Trailing-Universal Elimination in Quantified CNF

**Prepared for:** Miqueias B Werlich / Infinity Knowledge  
**Status:** working research note; elementary proof and finite computational audit, not peer reviewed. No claim of novelty, complexity-class breakthrough, external publication, or relationship to an unavailable framework is made.

## Abstract
We study a syntactic transformation of a finite CNF matrix with a trailing universal block. For each fixed assignment to the earlier variables, removing any clause containing both polarities of a universal variable and removing the remaining universal literals preserves the truth of the universally quantified matrix. We present an elementary proof, a direct truth-table oracle independently implemented from the transformation, exhaustive and seeded audits, and a family showing that reversing two quantifier blocks can change truth. The experiments cover 207,877 formula-partition cases across five exhaustive corpora, 787,763 fixed-assignment comparisons, and 1,800 random cases; no tested discrepancy was observed. This is a restricted and known universal-reduction setting, not a general QBF solver or evidence of a polynomial SAT algorithm.

## 1. Definitions and assumptions
Let X and Y be disjoint finite ordered sets of Boolean variables. An assignment maps each variable to 0 or 1. A literal is either a variable or its negation; in the code it is a positive or negative integer. A clause is a finite disjunction of literals and a CNF F a finite conjunction of clauses. The empty conjunction is true and the empty disjunction is false. Variables not occurring in the matrix are permitted. Repetition, tautological clauses, and empty partitions are permitted. The implementation validates that every literal is declared and variables are positive, distinct and disjoint.

For a clause C, if some y in Y occurs in both polarities, drop C. Otherwise remove every Y-literal from C; retain all other literals, including repeats. Apply the operation to each clause independently and call the resulting CNF P_Y(F). Other tautologies (e.g. an X-variable appearing in both polarities) may remain; this is harmless.

## 2. Proposition and proof (mathematical argument; no novelty claimed)
**Proposition.** For every assignment a of X, P_Y(F)(a) is true if and only if F(a,b) is true for every assignment b of Y. Consequently, ∃X ∀Y F is true if and only if ∃X P_Y(F) is true.

**Proof.** Universal quantification commutes with finite conjunction: for fixed a, ∀b [∧_C C(a,b)] is equivalent to ∧_C [∀b C(a,b)]. Consider one clause. If a satisfies at least one X-literal then the clause and its retained X-part are true for every b. Otherwise its truth depends only on its Y-literals. If some y appears with both signs, the clause is true under every b and deleting it from the conjunction is sound. If no y appears with both signs, choose, simultaneously for each Y-variable occurring in the clause, the value that makes its occurrences false; such a choice exists even with duplicate literals. Thus the Y-disjunction is not universally true. In that case, the original clause is true for every b exactly when its retained X-part is true. This also covers no Y-literals, empty clauses, and Y empty: an empty disjunction is false. The conjunction over the retained clauses is P_Y(F); existentially quantifying a gives the second statement. ∎

A universal-tautological clause must be discarded *before* deleting its universal literals. Simply deleting all universal literals from `(y ∨ ¬y)` would wrongly turn true into false; `test_bad_rule_is_detected` exercises that failure.

## 3. Quantifier ordering and an infinite strict family
For arbitrary finite X,Y and F, ∃X∀Y F implies ∀Y∃X F: a single winning X assignment also serves for each Y assignment. The converse does not hold. Let X={x1,…,xk}, Y={y1,…,yk}, k≥1, and let F_k be the conjunction of `(¬xi ∨ yi) ∧ (xi ∨ ¬yi)` over i. Then F_k enforces x_i=y_i. In ∀Y∃X F_k, choose X=Y; it is true. In ∃X∀Y F_k no single X works for both values of y1; it is false. Projection contains both xi and ¬xi for every i. This is a transparent dependency illustration, not a new separation result. The code separately checks k=1,…,7.

## 4. Algorithmic scope and limits
The transformation produces no more clauses or literals than the input. In this straightforward implementation a membership test is made for each universal variable in each clause, giving an upper bound O(L + C|Y|) expected time using hash sets, for L literal occurrences and C clauses. Further deciding the remaining CNF is ordinary SAT; because Y may be empty, the transformation does not eliminate general SAT difficulty. The implementation uses elementary DPLL with unit propagation, not a competitive solver, and may take exponential time or hit Python recursion limits. The complete truth-table oracle uses O(2^n) Boolean entries and evaluates all rows; its measured time includes matrix evaluation and folding. It is intended only for small n.

This identity concerns a trailing universal block and every fixed assignment to preceding variables. Do not blindly delete universal literals when a later existential variable depends on them. For example, ∀y∃x [x↔y] is true, while removing both y-literals yields x∧¬x, which is false. Arbitrary alternation is supported by the truth-table oracle, not by the projection solver. The code produces no formal proof certificate or winning strategy.

## 5. Experimental method
`truth_oracle.py` imports no projection or SAT code. It constructs each Boolean assignment from `itertools.product`, evaluates the original matrix literally, and folds the truth vector from the rightmost quantified variable: adjacent rows use OR for ∃ and AND for ∀. It also aggregates full truth-table rows over Y for each fixed X. `qbf_projection.py` transforms clauses using sets and independently searches the result with DPLL. The oracle's generic matrix evaluator is also used to evaluate the projected matrix; shared truth-table evaluation remains a common-mode risk. The paths are independent at the level of quantifier evaluation versus syntactic reduction, but neither implementation is formally verified or cross-checked with a third-party QBF solver.

Exhaustive corpus: for each variable, a syntactic clause has four states (absent, positive, negative, both), with canonical literal ordering. Formulas are distinct *sets* of up to m distinct clauses, in deterministic combination order; these are syntactic, not semantically distinct. The n=3 universe has 4³=64 clauses and sizes 0–3, hence 1+64+2,016+41,664=43,745 formulas. We test all four contiguous X/Y partitions k=0,…,3. The n=4 corpus has 4⁴=256 clauses, sizes 0–2, hence 32,897 formulas with |X|=|Y|=2. Every fixed X assignment is tested. This expands and independently rechecks the previous 20 November n=4 corpus without importing its code.

Random corpus: seed 20261121; each of 36 strata contains 50 draws. Partitions (|X|,|Y|) are (1,1), (2,2), (3,3), (4,2), (2,4); widths 2 and 3 are used where possible, clause counts 2,4,8,12. Each clause chooses distinct variables uniformly without replacement and independent signs; clauses are sampled independently, so duplicate clauses and duplicate formulas are possible but within-clause tautologies and repeated literals are excluded. The corpus is a designed stress sample, not a representative population or a proof of general performance. Full inputs, outputs, DPLL node counts, and individual timings are retained in `random_cases.jsonl`.

## 6. Results from the recorded run
| Corpus | X,Y sizes | Formula-partition cases | Fixed X rows | EF true | FE true | FE true / EF false |
|---|---:|---:|---:|---:|---:|---:|
| n=3, ≤3 clauses | 0,3 | 43,745 | 43,745 | 8,474 | 8,474 | 0 |
| n=3, ≤3 clauses | 1,2 | 43,745 | 87,490 | 24,050 | 25,370 | 1,320 |
| n=3, ≤3 clauses | 2,1 | 43,745 | 174,980 | 36,622 | 36,942 | 320 |
| n=3, ≤3 clauses | 3,0 | 43,745 | 349,960 | 41,518 | 41,518 | 0 |
| n=4, ≤2 clauses | 2,2 | 32,897 | 131,588 | 30,467 | 30,531 | 64 |

EF abbreviates ∃X∀Y F and FE abbreviates ∀Y∃X F. All five corpora had **zero** projection residual mismatches, DPLL/oracle decision mismatches, and implication violations. Total rows: 787,763; total formula-partition cases: 207,877. The n=3 formulas recur across different partitions, so this is not a count of distinct matrices. The n=4 counts reproduce the earlier 32,897/64 audit under the same corpus conventions.

Across 1,800 random draws, EF was true 523 times, FE 653 times, and the strict-order gap occurred 130 times; there were zero residual mismatches and implication violations. For example, X=2,Y=2,width=3,4 clauses had 25 EF-true, 44 FE-true, and 19 strict gaps among 50 draws. These totals are descriptive for this fixed seed and design only, with no population or causal inference. Seven equality-family cases passed. An intentional incorrect rule is caught by a unit test.

The recorded run timed 49,516,260 ns total for the EF truth-table decision and 27,104,591 ns total for projection plus DPLL across the 1,800 draws. These are single, fixed-order paired wall-clock observations for tiny inputs, with different output work, interpreter and measurement overhead, no warm-up control or uncertainty analysis; they do **not** establish a general speedup or portable performance ranking. The FE and fixed-assignment checks are not included in those respective timings. DPLL node counts sum to 2,048; they count recursive calls, not propagation steps or a machine-independent cost.

## 7. Reproduction and data provenance
Run from this directory with Python 3.8+ (standard library only):

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_qbf
PYTHONDONTWRITEBYTECODE=1 python3 verify_artifacts.py
PYTHONDONTWRITEBYTECODE=1 python3 experiments.py
```

The first command exercises 11 test methods, including 500 seeded randomized general cases, arbitrary-prefix examples, invalid inputs, equality cases, and all 256 single clauses across five partitions. The second verifies the retained raw JSONL SHA-256, recomputes all 1,800 decisions, residuals, DPLL node counts, and group aggregates. It does not rerun exhaustive cases; the third reruns all experiments and replaces `results.json` and `random_cases.jsonl` in this directory. The recorded run used Python 3.14.4 and records `sys.version`, platform, seed, and corpus hashes in `results.json`. Timing fields vary on every run, so the raw file checksum also varies; the deterministic exhaustive *input* hashes omit timings. Python's pseudorandom implementation and timings may vary by version; the retained JSONL is the definitive record of generated random inputs. The programs require no external packages, but Android/Termux execution has not been tested. Do not infer preservation of this ephemeral sandbox or external backup.

## 8. Literature and relationship
Universal reduction and quantified-CNF solving are established. Bubeck [1, §2.4] explicitly describes universal reduction on a non-tautological clause when the universal literal does not dominate any existential literal in the clause. The present two-block trailing-universal setting has that ordering, and the explicit removal of universally tautological clauses handles a case excluded by that stated non-tautological rule. This comparison is not a claim that our implementation is a full general universal-reduction system. Beyersdorff et al. [2] survey QBF algorithms and proof systems; the Yale notes [3] give a standard account of TQBF and polynomial-space evaluation. None is a citation for a novelty claim here.

[1] U. Bubeck, *Model-Based Transformations for Quantified Boolean Formulas*, Dissertations in Artificial Intelligence, vol. 329, IOS Press, 2010, §2.4. ISBN 978-1-60750-545-7. https://www.ub-net.de/cms/fileadmin/upb/doc/bubeck-qbf-transformations-2010.pdf

[2] O. Beyersdorff, M. Janota, F. Lonsing, M. Seidl, “Chapter 31. Quantified Boolean Formulas,” 2021, DOI: https://doi.org/10.3233/FAIA201015

[3] Yale University, *TQBF is PSPACE-complete*, course notes. https://zoo.cs.yale.edu/classes/cs468/previous-years/fall12/TQBF-complete.pdf

## 9. Next independent checks
Cross-validate generated inputs and results using a maintained external QBF solver and an independently checked certificate where applicable; add QDIMACS export and round-trip tests; examine richer random distributions and larger structured instances; measure repeated randomized-order trials if benchmarking is a goal; test actual Termux/Android; obtain expert mathematical review. The owner's earlier ASOG/framework source remains unavailable, so no equivalence, origin, or priority claim is possible. These are future tasks, not results of this run.
