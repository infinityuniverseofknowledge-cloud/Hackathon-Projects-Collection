# Infinity Knowledge: Research Expansion, 21 November 2026

Prepared for Miqueias B Werlich / Infinity Knowledge. Two independent preliminary research lines; this is not peer-reviewed and makes no claim to a novel discovery. It is not evidence of an ASOG equivalence or continuation of inaccessible master definitions. The earlier checkpoint and source files are preserved separately.

## Contents
- `math/MANUSCRIPT.md`: definitions, an elementary argument for a known restricted universal reduction, quantifier-order counterexamples, computational methods and limitations.
- `math/`: reproducible projection and truth-table algorithms, tests, results and 1,800 stored random cases. `python3 -m unittest -v test_qbf` and `python3 verify_artifacts.py`; `python3 experiments.py` regenerates files and overwrites results, so work in a copy to preserve the originals. One complete rerun in an isolated copy matched counts, corpus hashes, decisions and equality-family results; elapsed timings are expected to differ.
- `ecology/MANUSCRIPT.md`: paired toy-model experiment, uncertainty, exclusions, limitations and reference list.
- `ecology/patch_lab.html`: standalone interactive ring-patch simulator. Use `ecology/README.md` for reproducibility. The visual simulator uses another generator and is not an exact reproduction of the experiment.
- `ecology/`: Python and JavaScript model code, raw paired and trajectory CSVs, summaries, tests, data verifier, replay checks and HTML build source. `python3 test_model.py`, `python3 verify_data.py` and `python3 verify_replay.py`; experiment regeneration overwrites stored CSV/JSON, so work in a copy.

## Confirmed checkpoint
Mathematics: 207,877 formula-partition cases and 787,763 fixed-X comparisons, with no discrepancies observed within this finite corpus; 1,800 random cases in 36 groups; 11 tests passed. The truth-table oracle and transformation are separate but share matrix evaluation in some comparisons; there is no external solver validation. The elementary proof is not a novelty claim and the residual SAT problem remains hard in general.

Ecology: 1,440 attempted paired runs, 1,305 eligible, with exactly 12 occupied patches removed per treatment in eligible pairs, two generators, nine parameter settings, 100-step follow-up; 16 tests passed including Python-JavaScript parity on supplied draws. Raw data audit covers 131,805 trajectory rows; 54 selected attempts replayed. At c=0.12 and e=0.16, only 13 and 14 of 80 runs per generator were eligible. Selection, treatment definitions, censoring and shared random numbers matter. All data are simulated; these are exploratory model observations, not biological evidence.

A desktop Chromium headless smoke test was recorded in the ecology notes; actual Android, accessibility, empirical validation, independent external review and production use remain unverified. A direct run of `parity.cjs` without stdin is invalid; it is invoked with JSON input by `test_model.py` and is not a separate standalone test. Preserve `ecology/SHA256SUMS.txt` with ecology files to verify the original ecology export (`sha256sum -c SHA256SUMS.txt` inside ecology).

## Next independent work
1. Independent expert review, cross-check with an external QBF solver, and assess formal proof boundaries and literature.
2. Pre-register ecological analyses, reduce selection effects and confounding, vary topology and severity, test uncertainty and independent full-protocol implementations.
3. Verify mobile usability, Android/Termux, accessibility and performance on physical devices.
4. Recover the master record and determine relationships to previous frameworks only from verifiable definitions. No automatic merge or publication of the research as peer reviewed.
